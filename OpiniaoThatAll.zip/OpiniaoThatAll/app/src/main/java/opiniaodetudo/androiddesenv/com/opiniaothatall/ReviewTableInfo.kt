package opiniaodetudo.androiddesenv.com.opiniaothatall

object ReviewTableInfo {
    const val TABLE_NAME = "Review"
    const val COLUMN_ID = "id"
    const val COLUMN_NAME = "name"
    const val COLUMN_REVIEW = "review"
}