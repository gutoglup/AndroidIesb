package opiniaodetudo.androiddesenv.com.opiniaothatall

import android.arch.persistence.room.PrimaryKey

data class Review(
    @PrimaryKey
    val id: String,
    val name: String,
    val review: String?)