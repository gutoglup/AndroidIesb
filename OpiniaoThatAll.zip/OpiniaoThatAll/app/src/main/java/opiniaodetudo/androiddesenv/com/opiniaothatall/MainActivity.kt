package opiniaodetudo.androiddesenv.com.opiniaothatall

import android.content.Intent
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonSave = findViewById<Button>(R.id.button_save)
        val textFieldName = findViewById<EditText>(R.id.textfield_name)
        val textFieldOpinion = findViewById<EditText>(R.id.textfield_opinion)

        buttonSave.setOnClickListener{
            val name = textFieldName.text
            val review = textFieldOpinion.text
            object: AsyncTask <Void, Void, Unit>() {
                override fun doInBackground(vararg params: Void?) {
                    val repository = ReviewRepository(this@MainActivity.applicationContext)
                    repository.save(name.toString(), review.toString())
                    startActivity(Intent(this@MainActivity, ListActivity::class.java))
                }
            }
        }
    }
}
